<?php
/**
 * LangSuggest classfile
 *
 * Copyright 2019 by Thomas Jakobi <thomas.jakobi@partout.info>
 *
 * @package langsuggest
 * @subpackage classfile
 */

require_once dirname(dirname(__DIR__)) . '/vendor/autoload.php';

/**
 * Class LangSuggest
 */
class LangSuggest extends \TreehillStudio\LangSuggest\LangSuggest
{
}
