<?php
/**
 * Setting Lexicon Entries for LangSuggest
 *
 * @package langsuggest
 * @subpackage lexicon
 */
$_lang['setting_langsuggest.chunk_position'] = 'Chunk-Position';
$_lang['setting_langsuggest.chunk_position_desc'] = 'Die Position der Ausgabe des LangSuggest-Chunks im Body-Bereich der gerenderten Seite. Kann auf `top` oder `bottom` gesetzt werden.';
$_lang['setting_langsuggest.cookie_expiration'] = 'Cookie-Ablauf';
$_lang['setting_langsuggest.cookie_expiration_desc'] = 'Die Anzahl der Tage, die LangSuggest ausgeblendet bleibt, nachdem die Sprache über die Schaltfläche gewechselt wurde. 0 erzeugt ein Sitzungs-Cookie.';
$_lang['setting_langsuggest.cookie_name'] = 'Cookie-Name';
$_lang['setting_langsuggest.cookie_name_desc'] = 'Der Name des Cookies, das von LangSuggest festgelegt wird, wenn die Sprache gewechselt werden soll. Andere Zeichen als Buchstaben, Ziffern, `_` und `-` werden durch `_` ersetzt.';
$_lang['setting_langsuggest.debug'] = 'Debug';
$_lang['setting_langsuggest.debug_desc'] = 'Debug-Informationen im MODX-Fehlerprotokoll ausgeben.';
$_lang['setting_langsuggest.display_count'] = 'Anzahl der Meldungen';
$_lang['setting_langsuggest.display_count_desc'] = 'Maximale Anzahl der Meldungen des LangSuggest-Modals für jede Sitzung, wenn eine PHP-Sitzung existiert.';
$_lang['setting_langsuggest.no_session'] = 'Sessionslose Kontexte';
$_lang['setting_langsuggest.no_session_desc'] = 'LangSuggest in sessionslosen Kontexten anzeigen.';
$_lang['setting_langsuggest.tpl'] = 'Modal-Template';
$_lang['setting_langsuggest.tpl_desc'] = 'Der Template-Chunk, der das LangSuggest-Modal enthält.';
