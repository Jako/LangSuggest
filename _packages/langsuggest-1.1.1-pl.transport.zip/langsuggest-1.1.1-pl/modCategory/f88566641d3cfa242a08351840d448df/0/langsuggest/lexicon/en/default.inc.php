<?php
/**
 * Default Lexicon Entries for LangSuggest
 *
 * @package langsuggest
 * @subpackage lexicon
 */
$_lang['langsuggest.bar_message'] = 'Would you prefer to continue reading on our English page? Then select your language here to see the content in your language.';
$_lang['langsuggest.redirect_message'] = 'Do you prefer being redirected to our English language page?';
$_lang['langsuggest.redirect_title'] = 'A brief question …';
