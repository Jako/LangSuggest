<?php
/**
 * Default Lexicon Entries for LangSuggest
 *
 * @package langsuggest
 * @subpackage lexicon
 */
$_lang['langsuggest.bar_message'] = 'Möchten Sie lieber auf unserer deutschsprachigen Seite weiterlesen? Dann wählen Sie hier Ihre Sprache, um die Inhalte in Ihrer Sprache zu sehen.';
$_lang['langsuggest.redirect_message'] = 'Möchten Sie auf unsere deutschsprachige Seite weitergeleitet werden?';
$_lang['langsuggest.redirect_title'] = 'Kurz nachgefragt …';
