<?php
/**
 * Default Lexicon Entries for LangSuggest
 *
 * @package langsuggest
 * @subpackage lexicon
 */
$_lang['langsuggest.bar_message'] = '¿Prefiere seguir leyendo en nuestra página en español? Entonces seleccione su idioma aquí para ver el contenido en su idioma.';
$_lang['langsuggest.redirect_message'] = '¿Prefiere ser redirigido a nuestra página web en español?';
$_lang['langsuggest.redirect_title'] = 'Una breve pregunta …';
