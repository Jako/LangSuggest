<?php
/**
 * Default Lexicon Entries for LangSuggest
 *
 * @package langsuggest
 * @subpackage lexicon
 */
$_lang['langsuggest.bar_message'] = 'Preferisci continuare a leggere sul nostro sito italiano? Allora seleziona qui la tua lingua per vedere il contenuto nella tua lingua.';
$_lang['langsuggest.redirect_title'] = 'Una breve domanda …';
$_lang['langsuggest.redirect_message'] = 'Preferisci essere reindirizzato alla nostra homepage in lingua italiana?';
