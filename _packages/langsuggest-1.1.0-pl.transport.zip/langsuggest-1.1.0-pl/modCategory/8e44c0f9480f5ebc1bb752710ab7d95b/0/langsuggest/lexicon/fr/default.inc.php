<?php
/**
 * Default Lexicon Entries for LangSuggest
 *
 * @package langsuggest
 * @subpackage lexicon
 */
$_lang['langsuggest.bar_message'] = 'Vous préférez continuer à lire sur notre site français ? Sélectionnez alors votre langue ici pour voir le contenu dans votre langue.';
$_lang['langsuggest.redirect_message'] = 'Préférez-vous être redirigé vers notre page d\'accueil en français ?';
$_lang['langsuggest.redirect_title'] = 'Une brève question …';
