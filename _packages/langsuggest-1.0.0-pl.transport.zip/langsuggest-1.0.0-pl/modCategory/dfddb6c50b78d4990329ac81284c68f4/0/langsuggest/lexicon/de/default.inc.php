<?php
$_lang['langsuggest.redirect_title'] = 'Kurz nachgefragt …';
$_lang['langsuggest.redirect_message'] = 'Möchten Sie auf unsere deutschsprachige Seite weitergeleitet werden?';
