<?php
$_lang['langsuggest.redirect_title'] = 'A brief question …';
$_lang['langsuggest.redirect_message'] = 'Do you prefer being redirected to our English language homepage?';
